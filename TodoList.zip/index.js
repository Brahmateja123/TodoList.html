import ReactDOM from "react-dom";
import App from "./App"
import TodoList from "./App";
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
    <>
    <TodoList/>
    

    </>

);
